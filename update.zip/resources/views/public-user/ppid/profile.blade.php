<!-- Profile Section -->
<section id="profilePPID" class="h-screen bg-gradient-to-b from-white to-gray-100 dark:from-gray-900 dark:to-gray-900 text-gray-800 dark:text-gray-100 py-20">
  <div class="max-w-7xl mx-auto px-4">
      <h1 class="text-4xl font-bold mb-4 text-center">Profile PPID Desa Pemali</h1>
      <p class="text-lg">{!! $ppid->profil !!}</p>
  </div>
</section>
