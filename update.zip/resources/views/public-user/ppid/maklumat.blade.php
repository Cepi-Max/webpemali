<section id="maklumat" class="hidden h-screen bg-gradient-to-b from-white to-gray-100 dark:from-gray-900 dark:to-gray-900 text-gray-800 dark:text-gray-100 py-20">
    <div class="max-w-7xl mx-auto px-4">
        <h1 class="text-4xl font-bold mb-4 text-center">Maklumat Pelayanan Informasi Publik</h1>
        <p class="text-lg">{!! $ppid->maklumat !!}</p>
    </div>
</section>