<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DataKewarganegaraan extends Model
{
    //
    protected $guarded = [];
}
