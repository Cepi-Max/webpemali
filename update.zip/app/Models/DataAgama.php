<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DataAgama extends Model
{
    //
    protected $guarded = [];
}
