<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DataDusun extends Model
{
    //
    protected $guarded = [];
}
