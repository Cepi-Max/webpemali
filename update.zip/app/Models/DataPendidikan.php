<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DataPendidikan extends Model
{
    protected $guarded = [];
}
